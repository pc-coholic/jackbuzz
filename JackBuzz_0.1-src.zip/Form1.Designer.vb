﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pbBuzzer1Button4 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer1Button3 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer1Button2 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer1Button1 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer1ButtonB = New System.Windows.Forms.PictureBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnPlayer1 = New System.Windows.Forms.Button
        Me.btnPlayer2 = New System.Windows.Forms.Button
        Me.PictureBox7 = New System.Windows.Forms.PictureBox
        Me.btnPlayer3 = New System.Windows.Forms.Button
        Me.PictureBox8 = New System.Windows.Forms.PictureBox
        Me.btnPlayerAdmin = New System.Windows.Forms.Button
        Me.PictureBox9 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer2Button4 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer2Button3 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer2Button2 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer2Button1 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer2ButtonB = New System.Windows.Forms.PictureBox
        Me.pbBuzzer3Button4 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer3Button3 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer3Button2 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer3Button1 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer3ButtonB = New System.Windows.Forms.PictureBox
        Me.pbBuzzer4Button4 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer4Button3 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer4Button2 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer4Button1 = New System.Windows.Forms.PictureBox
        Me.pbBuzzer4ButtonB = New System.Windows.Forms.PictureBox
        Me.tmrBlink = New System.Windows.Forms.Timer(Me.components)
        Me.tmrButtons = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        CType(Me.pbBuzzer1Button4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer1Button3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer1Button2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer1Button1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer1ButtonB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer2Button4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer2Button3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer2Button2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer2Button1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer2ButtonB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer3Button4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer3Button3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer3Button2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer3Button1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer3ButtonB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer4Button4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer4Button3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer4Button2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer4Button1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBuzzer4ButtonB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbBuzzer1Button4
        '
        Me.pbBuzzer1Button4.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_10
        Me.pbBuzzer1Button4.Location = New System.Drawing.Point(88, 299)
        Me.pbBuzzer1Button4.Name = "pbBuzzer1Button4"
        Me.pbBuzzer1Button4.Size = New System.Drawing.Size(142, 78)
        Me.pbBuzzer1Button4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer1Button4.TabIndex = 5
        Me.pbBuzzer1Button4.TabStop = False
        Me.pbBuzzer1Button4.Visible = False
        '
        'pbBuzzer1Button3
        '
        Me.pbBuzzer1Button3.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_09
        Me.pbBuzzer1Button3.Location = New System.Drawing.Point(88, 250)
        Me.pbBuzzer1Button3.Name = "pbBuzzer1Button3"
        Me.pbBuzzer1Button3.Size = New System.Drawing.Size(142, 46)
        Me.pbBuzzer1Button3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer1Button3.TabIndex = 4
        Me.pbBuzzer1Button3.TabStop = False
        Me.pbBuzzer1Button3.Visible = False
        '
        'pbBuzzer1Button2
        '
        Me.pbBuzzer1Button2.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_08
        Me.pbBuzzer1Button2.Location = New System.Drawing.Point(88, 210)
        Me.pbBuzzer1Button2.Name = "pbBuzzer1Button2"
        Me.pbBuzzer1Button2.Size = New System.Drawing.Size(142, 41)
        Me.pbBuzzer1Button2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer1Button2.TabIndex = 3
        Me.pbBuzzer1Button2.TabStop = False
        Me.pbBuzzer1Button2.Visible = False
        '
        'pbBuzzer1Button1
        '
        Me.pbBuzzer1Button1.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_07
        Me.pbBuzzer1Button1.Location = New System.Drawing.Point(88, 160)
        Me.pbBuzzer1Button1.Name = "pbBuzzer1Button1"
        Me.pbBuzzer1Button1.Size = New System.Drawing.Size(142, 51)
        Me.pbBuzzer1Button1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer1Button1.TabIndex = 2
        Me.pbBuzzer1Button1.TabStop = False
        Me.pbBuzzer1Button1.Visible = False
        '
        'pbBuzzer1ButtonB
        '
        Me.pbBuzzer1ButtonB.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_05
        Me.pbBuzzer1ButtonB.Location = New System.Drawing.Point(88, 12)
        Me.pbBuzzer1ButtonB.Name = "pbBuzzer1ButtonB"
        Me.pbBuzzer1ButtonB.Size = New System.Drawing.Size(142, 149)
        Me.pbBuzzer1ButtonB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer1ButtonB.TabIndex = 1
        Me.pbBuzzer1ButtonB.TabStop = False
        Me.pbBuzzer1ButtonB.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(88, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(142, 365)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnPlayer1
        '
        Me.btnPlayer1.Location = New System.Drawing.Point(88, 383)
        Me.btnPlayer1.Name = "btnPlayer1"
        Me.btnPlayer1.Size = New System.Drawing.Size(142, 23)
        Me.btnPlayer1.TabIndex = 6
        Me.btnPlayer1.Text = "Player 1 (Q)"
        Me.btnPlayer1.UseVisualStyleBackColor = True
        '
        'btnPlayer2
        '
        Me.btnPlayer2.Location = New System.Drawing.Point(236, 383)
        Me.btnPlayer2.Name = "btnPlayer2"
        Me.btnPlayer2.Size = New System.Drawing.Size(142, 23)
        Me.btnPlayer2.TabIndex = 8
        Me.btnPlayer2.Text = "Player 2 (B)"
        Me.btnPlayer2.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(236, 12)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(142, 365)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox7.TabIndex = 7
        Me.PictureBox7.TabStop = False
        '
        'btnPlayer3
        '
        Me.btnPlayer3.Location = New System.Drawing.Point(384, 383)
        Me.btnPlayer3.Name = "btnPlayer3"
        Me.btnPlayer3.Size = New System.Drawing.Size(142, 23)
        Me.btnPlayer3.TabIndex = 10
        Me.btnPlayer3.Text = "Player 3 (P)"
        Me.btnPlayer3.UseVisualStyleBackColor = True
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(384, 12)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(142, 365)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox8.TabIndex = 9
        Me.PictureBox8.TabStop = False
        '
        'btnPlayerAdmin
        '
        Me.btnPlayerAdmin.Location = New System.Drawing.Point(547, 383)
        Me.btnPlayerAdmin.Name = "btnPlayerAdmin"
        Me.btnPlayerAdmin.Size = New System.Drawing.Size(142, 23)
        Me.btnPlayerAdmin.TabIndex = 12
        Me.btnPlayerAdmin.Text = "Admin"
        Me.btnPlayerAdmin.UseVisualStyleBackColor = True
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(547, 12)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(142, 365)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox9.TabIndex = 11
        Me.PictureBox9.TabStop = False
        '
        'pbBuzzer2Button4
        '
        Me.pbBuzzer2Button4.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_10
        Me.pbBuzzer2Button4.Location = New System.Drawing.Point(236, 299)
        Me.pbBuzzer2Button4.Name = "pbBuzzer2Button4"
        Me.pbBuzzer2Button4.Size = New System.Drawing.Size(142, 78)
        Me.pbBuzzer2Button4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer2Button4.TabIndex = 17
        Me.pbBuzzer2Button4.TabStop = False
        Me.pbBuzzer2Button4.Visible = False
        '
        'pbBuzzer2Button3
        '
        Me.pbBuzzer2Button3.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_09
        Me.pbBuzzer2Button3.Location = New System.Drawing.Point(236, 250)
        Me.pbBuzzer2Button3.Name = "pbBuzzer2Button3"
        Me.pbBuzzer2Button3.Size = New System.Drawing.Size(142, 46)
        Me.pbBuzzer2Button3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer2Button3.TabIndex = 16
        Me.pbBuzzer2Button3.TabStop = False
        Me.pbBuzzer2Button3.Visible = False
        '
        'pbBuzzer2Button2
        '
        Me.pbBuzzer2Button2.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_08
        Me.pbBuzzer2Button2.Location = New System.Drawing.Point(236, 210)
        Me.pbBuzzer2Button2.Name = "pbBuzzer2Button2"
        Me.pbBuzzer2Button2.Size = New System.Drawing.Size(142, 41)
        Me.pbBuzzer2Button2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer2Button2.TabIndex = 15
        Me.pbBuzzer2Button2.TabStop = False
        Me.pbBuzzer2Button2.Visible = False
        '
        'pbBuzzer2Button1
        '
        Me.pbBuzzer2Button1.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_07
        Me.pbBuzzer2Button1.Location = New System.Drawing.Point(236, 160)
        Me.pbBuzzer2Button1.Name = "pbBuzzer2Button1"
        Me.pbBuzzer2Button1.Size = New System.Drawing.Size(142, 51)
        Me.pbBuzzer2Button1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer2Button1.TabIndex = 14
        Me.pbBuzzer2Button1.TabStop = False
        Me.pbBuzzer2Button1.Visible = False
        '
        'pbBuzzer2ButtonB
        '
        Me.pbBuzzer2ButtonB.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_05
        Me.pbBuzzer2ButtonB.Location = New System.Drawing.Point(236, 12)
        Me.pbBuzzer2ButtonB.Name = "pbBuzzer2ButtonB"
        Me.pbBuzzer2ButtonB.Size = New System.Drawing.Size(142, 149)
        Me.pbBuzzer2ButtonB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer2ButtonB.TabIndex = 13
        Me.pbBuzzer2ButtonB.TabStop = False
        Me.pbBuzzer2ButtonB.Visible = False
        '
        'pbBuzzer3Button4
        '
        Me.pbBuzzer3Button4.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_10
        Me.pbBuzzer3Button4.Location = New System.Drawing.Point(384, 299)
        Me.pbBuzzer3Button4.Name = "pbBuzzer3Button4"
        Me.pbBuzzer3Button4.Size = New System.Drawing.Size(142, 78)
        Me.pbBuzzer3Button4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer3Button4.TabIndex = 22
        Me.pbBuzzer3Button4.TabStop = False
        Me.pbBuzzer3Button4.Visible = False
        '
        'pbBuzzer3Button3
        '
        Me.pbBuzzer3Button3.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_09
        Me.pbBuzzer3Button3.Location = New System.Drawing.Point(384, 250)
        Me.pbBuzzer3Button3.Name = "pbBuzzer3Button3"
        Me.pbBuzzer3Button3.Size = New System.Drawing.Size(142, 46)
        Me.pbBuzzer3Button3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer3Button3.TabIndex = 21
        Me.pbBuzzer3Button3.TabStop = False
        Me.pbBuzzer3Button3.Visible = False
        '
        'pbBuzzer3Button2
        '
        Me.pbBuzzer3Button2.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_08
        Me.pbBuzzer3Button2.Location = New System.Drawing.Point(384, 210)
        Me.pbBuzzer3Button2.Name = "pbBuzzer3Button2"
        Me.pbBuzzer3Button2.Size = New System.Drawing.Size(142, 41)
        Me.pbBuzzer3Button2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer3Button2.TabIndex = 20
        Me.pbBuzzer3Button2.TabStop = False
        Me.pbBuzzer3Button2.Visible = False
        '
        'pbBuzzer3Button1
        '
        Me.pbBuzzer3Button1.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_07
        Me.pbBuzzer3Button1.Location = New System.Drawing.Point(384, 160)
        Me.pbBuzzer3Button1.Name = "pbBuzzer3Button1"
        Me.pbBuzzer3Button1.Size = New System.Drawing.Size(142, 51)
        Me.pbBuzzer3Button1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer3Button1.TabIndex = 19
        Me.pbBuzzer3Button1.TabStop = False
        Me.pbBuzzer3Button1.Visible = False
        '
        'pbBuzzer3ButtonB
        '
        Me.pbBuzzer3ButtonB.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_05
        Me.pbBuzzer3ButtonB.Location = New System.Drawing.Point(384, 12)
        Me.pbBuzzer3ButtonB.Name = "pbBuzzer3ButtonB"
        Me.pbBuzzer3ButtonB.Size = New System.Drawing.Size(142, 149)
        Me.pbBuzzer3ButtonB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer3ButtonB.TabIndex = 18
        Me.pbBuzzer3ButtonB.TabStop = False
        Me.pbBuzzer3ButtonB.Visible = False
        '
        'pbBuzzer4Button4
        '
        Me.pbBuzzer4Button4.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_10
        Me.pbBuzzer4Button4.Location = New System.Drawing.Point(547, 299)
        Me.pbBuzzer4Button4.Name = "pbBuzzer4Button4"
        Me.pbBuzzer4Button4.Size = New System.Drawing.Size(142, 78)
        Me.pbBuzzer4Button4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer4Button4.TabIndex = 27
        Me.pbBuzzer4Button4.TabStop = False
        Me.pbBuzzer4Button4.Visible = False
        '
        'pbBuzzer4Button3
        '
        Me.pbBuzzer4Button3.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_09
        Me.pbBuzzer4Button3.Location = New System.Drawing.Point(547, 250)
        Me.pbBuzzer4Button3.Name = "pbBuzzer4Button3"
        Me.pbBuzzer4Button3.Size = New System.Drawing.Size(142, 46)
        Me.pbBuzzer4Button3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer4Button3.TabIndex = 26
        Me.pbBuzzer4Button3.TabStop = False
        Me.pbBuzzer4Button3.Visible = False
        '
        'pbBuzzer4Button2
        '
        Me.pbBuzzer4Button2.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_08
        Me.pbBuzzer4Button2.Location = New System.Drawing.Point(547, 210)
        Me.pbBuzzer4Button2.Name = "pbBuzzer4Button2"
        Me.pbBuzzer4Button2.Size = New System.Drawing.Size(142, 41)
        Me.pbBuzzer4Button2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer4Button2.TabIndex = 25
        Me.pbBuzzer4Button2.TabStop = False
        Me.pbBuzzer4Button2.Visible = False
        '
        'pbBuzzer4Button1
        '
        Me.pbBuzzer4Button1.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_07
        Me.pbBuzzer4Button1.Location = New System.Drawing.Point(547, 160)
        Me.pbBuzzer4Button1.Name = "pbBuzzer4Button1"
        Me.pbBuzzer4Button1.Size = New System.Drawing.Size(142, 51)
        Me.pbBuzzer4Button1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer4Button1.TabIndex = 24
        Me.pbBuzzer4Button1.TabStop = False
        Me.pbBuzzer4Button1.Visible = False
        '
        'pbBuzzer4ButtonB
        '
        Me.pbBuzzer4ButtonB.Image = Global.JackBuzz.My.Resources.Resources.Buzz_Buzzer_05
        Me.pbBuzzer4ButtonB.Location = New System.Drawing.Point(547, 12)
        Me.pbBuzzer4ButtonB.Name = "pbBuzzer4ButtonB"
        Me.pbBuzzer4ButtonB.Size = New System.Drawing.Size(142, 149)
        Me.pbBuzzer4ButtonB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pbBuzzer4ButtonB.TabIndex = 23
        Me.pbBuzzer4ButtonB.TabStop = False
        Me.pbBuzzer4ButtonB.Visible = False
        '
        'tmrBlink
        '
        Me.tmrBlink.Interval = 1000
        '
        'tmrButtons
        '
        Me.tmrButtons.Enabled = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 87)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Player Button"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 182)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Answer 1 / [1]"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 225)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Answer 2 / [2]"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 267)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Answer 3 / [3]"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 314)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Answer 4 / [4]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(695, 314)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Not in use"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(695, 267)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Not in use"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(695, 225)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Not in use"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(695, 182)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 13)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "[N] / Screw"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(695, 87)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "[ESC] / Pause"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 415)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pbBuzzer4Button4)
        Me.Controls.Add(Me.pbBuzzer4Button3)
        Me.Controls.Add(Me.pbBuzzer4Button2)
        Me.Controls.Add(Me.pbBuzzer4Button1)
        Me.Controls.Add(Me.pbBuzzer4ButtonB)
        Me.Controls.Add(Me.pbBuzzer3Button4)
        Me.Controls.Add(Me.pbBuzzer3Button3)
        Me.Controls.Add(Me.pbBuzzer3Button2)
        Me.Controls.Add(Me.pbBuzzer3Button1)
        Me.Controls.Add(Me.pbBuzzer3ButtonB)
        Me.Controls.Add(Me.pbBuzzer2Button4)
        Me.Controls.Add(Me.pbBuzzer2Button3)
        Me.Controls.Add(Me.pbBuzzer2Button2)
        Me.Controls.Add(Me.pbBuzzer2Button1)
        Me.Controls.Add(Me.pbBuzzer2ButtonB)
        Me.Controls.Add(Me.btnPlayerAdmin)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.btnPlayer3)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.btnPlayer2)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.btnPlayer1)
        Me.Controls.Add(Me.pbBuzzer1Button4)
        Me.Controls.Add(Me.pbBuzzer1Button3)
        Me.Controls.Add(Me.pbBuzzer1Button2)
        Me.Controls.Add(Me.pbBuzzer1Button1)
        Me.Controls.Add(Me.pbBuzzer1ButtonB)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "JackBuzz :: 0.1"
        CType(Me.pbBuzzer1Button4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer1Button3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer1Button2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer1Button1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer1ButtonB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer2Button4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer2Button3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer2Button2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer2Button1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer2ButtonB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer3Button4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer3Button3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer3Button2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer3Button1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer3ButtonB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer4Button4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer4Button3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer4Button2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer4Button1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBuzzer4ButtonB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer1ButtonB As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer1Button1 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer1Button2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer1Button3 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer1Button4 As System.Windows.Forms.PictureBox
    Friend WithEvents btnPlayer1 As System.Windows.Forms.Button
    Friend WithEvents btnPlayer2 As System.Windows.Forms.Button
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents btnPlayer3 As System.Windows.Forms.Button
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents btnPlayerAdmin As System.Windows.Forms.Button
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer2Button4 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer2Button3 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer2Button2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer2Button1 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer2ButtonB As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer3Button4 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer3Button3 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer3Button2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer3Button1 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer3ButtonB As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer4Button4 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer4Button3 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer4Button2 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer4Button1 As System.Windows.Forms.PictureBox
    Friend WithEvents pbBuzzer4ButtonB As System.Windows.Forms.PictureBox
    Friend WithEvents tmrBlink As System.Windows.Forms.Timer
    Friend WithEvents tmrButtons As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label

End Class
